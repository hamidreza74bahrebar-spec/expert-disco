import { Student, EnrichedStudentData, EnrichedSubject, Subject, SubjectClassMetrics } from '../types';

export const toPersianDigits = (n: string | number | null | undefined): string => {
  if (n === null || n === undefined) return '-';
  const str = String(n);
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return str.replace(/[0-9]/g, (w) => persianDigits[+w]);
};

export const calculateSubjectAverage = (grades: (number | null)[]): number | null => {
  const validGrades = grades.filter(g => g !== null && !isNaN(g)) as number[];
  if (validGrades.length === 0) return null;
  const sum = validGrades.reduce((acc, grade) => acc + grade, 0);
  return parseFloat((sum / validGrades.length).toFixed(2));
};

export const calculateTotalAverage = (subjects: EnrichedSubject[]): number | null => {
  const validAverages = subjects.map(s => s.average).filter(avg => avg !== null) as number[];
  if (validAverages.length === 0) return null;
  const sum = validAverages.reduce((acc, avg) => acc + avg, 0);
  return parseFloat((sum / validAverages.length).toFixed(2));
};

export const calculateAllStudentMetrics = (students: Student[], subjectInclusion: { [key: string]: boolean }): EnrichedStudentData[] => {
  const enrichedData: EnrichedStudentData[] = students.map(student => {
    const enrichedSubjects: EnrichedSubject[] = student.subjects.map(subject => ({
      ...subject,
      average: calculateSubjectAverage(subject.grades),
    }));

    const subjectsForAverage = enrichedSubjects.filter(subject => subjectInclusion[subject.name]);
    const totalAverage = calculateTotalAverage(subjectsForAverage);

    return {
      ...student,
      subjects: enrichedSubjects,
      totalAverage,
      rank: null, // Rank will be calculated in the next step
      includeInReportCard: student.includeInReportCard !== false, // Default to true if undefined
    };
  });

  // Filter students to be included in ranking
  const studentsToRank = enrichedData.filter(s => s.includeInReportCard);

  // Sort by totalAverage to determine rank
  const sortedByAverage = [...studentsToRank].sort((a, b) => {
    if (b.totalAverage === null) return -1;
    if (a.totalAverage === null) return 1;
    return b.totalAverage - a.totalAverage;
  });

  const rankedStudentsMap = new Map<string, number>();

  // Assign ranks, handling ties
  let currentRank = 0;
  let lastAverage: number | null = null;
  sortedByAverage.forEach((student, index) => {
    if (student.totalAverage !== lastAverage) {
      currentRank = index + 1;
    }
    lastAverage = student.totalAverage;
    if (student.totalAverage !== null) {
      rankedStudentsMap.set(student.id, currentRank);
    }
  });

  // Map ranks back to the original full list of students
  const finalData = enrichedData.map(student => ({
    ...student,
    rank: rankedStudentsMap.get(student.id) ?? null,
  }));
  
  return finalData;
};

export const calculateSubjectClassMetrics = (students: Student[], subjectNames: string[]): SubjectClassMetrics[] => {
    return subjectNames.map(subjectName => {
        const allGradesForSubject = students.flatMap(student => {
            const subject = student.subjects.find(s => s.name === subjectName);
            return subject ? subject.grades : [];
        }).filter(g => g !== null && !isNaN(g)) as number[];

        if (allGradesForSubject.length === 0) {
            return { name: subjectName, average: 0, min: 0, max: 0 };
        }

        const sum = allGradesForSubject.reduce((acc, grade) => acc + grade, 0);
        const average = parseFloat((sum / allGradesForSubject.length).toFixed(2));
        const min = Math.min(...allGradesForSubject);
        const max = Math.max(...allGradesForSubject);
        return { name: subjectName, average, min, max };
    });
};