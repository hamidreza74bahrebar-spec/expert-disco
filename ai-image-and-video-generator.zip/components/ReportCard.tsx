import React from 'react';
import { SchoolInfo, EnrichedStudentData } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { NUM_GRADES_PER_SUBJECT } from '../constants';
import SignatureSection from './SignatureSection';
import { toPersianDigits } from '../services/calculationService';

type PaperSize = 'a4' | 'a5';
type Orientation = 'portrait' | 'landscape';
type Template = 'default' | 'modern' | 'formal';

interface Props {
  student: EnrichedStudentData;
  schoolInfo: SchoolInfo;
  className: string;
  theme: 'light' | 'dark' | 'print';
  paperSize: PaperSize;
  orientation: Orientation;
  showRank: boolean;
  template: string;
  showChart: boolean;
  chartHeight: number;
}

const ReportCard: React.FC<Props> = (props) => {
  const { student, schoolInfo, className, theme, paperSize, orientation, showRank, template, showChart, chartHeight } = props;

  const nameParts = student.name.split(' ');
  const firstName = nameParts[0] || '';
  const lastName = nameParts.slice(1).join(' ');

  const isLight = theme === 'light';
  const isPrint = theme === 'print';

  // Common styles based on theme
  const commonStyles = {
    gridStrokeColor: isPrint ? '#aaaaaa' : '#e5e7eb',
    tickFillColor: isPrint ? '#000000' : '#374151',
    barFillColor: isPrint ? '#4A4A4A' : '#3b82f6',
    tableBorderColor: isPrint ? '#000000' : '#d1d5db',
  };

  const tooltipStyle = {
    backgroundColor: isPrint ? '#ffffff' : '#ffffff',
    border: `1px solid ${commonStyles.tableBorderColor}`,
    color: isPrint ? '#000000' : '#374151',
    fontSize: '10px',
    padding: '2px 5px',
  };

  const dimensions = {
      a4: { portrait: 'w-[210mm] h-[297mm]', landscape: 'w-[297mm] h-[210mm]' },
      a5: { portrait: 'w-[148mm] h-[210mm]', landscape: 'w-[210mm] h-[148mm]' },
  };
  const dimensionClasses = dimensions[paperSize][orientation];

  const enabledSignatures = schoolInfo.signatures.filter(sig => sig.enabled);
  
  const chartData = student.subjects.map(s => ({ name: s.name, میانگین: s.average }));

  const FullGradesTable = () => (
    <table className={`w-full text-[10px] border-collapse border`} style={{ borderColor: commonStyles.tableBorderColor }}>
        <thead className={isPrint ? 'bg-gray-200' : 'bg-gray-100'}>
            <tr>
                <th className="p-1 border" style={{ borderColor: commonStyles.tableBorderColor }}>نام درس</th>
                {Array.from({ length: NUM_GRADES_PER_SUBJECT }).map((_, i) => (
                    <th key={i} className="p-1 border" style={{ borderColor: commonStyles.tableBorderColor }}>{`نمره ${toPersianDigits(i+1)}`}</th>
                ))}
                <th className={`p-1 border font-bold ${isPrint ? 'bg-gray-300' : 'bg-blue-100'}`} style={{ borderColor: commonStyles.tableBorderColor }}>میانگین درس</th>
            </tr>
        </thead>
        <tbody>
            {student.subjects.map((subject, index) => (
                <tr key={index} className={isPrint ? '' : 'hover:bg-gray-50'}>
                    <td className="p-1 border font-semibold" style={{ borderColor: commonStyles.tableBorderColor }}>{subject.name}</td>
                    {subject.grades.map((grade, gIndex) => (
                        <td key={gIndex} className="p-1 border text-center" style={{ borderColor: commonStyles.tableBorderColor }}>{toPersianDigits(grade?.toFixed(2))}</td>
                    ))}
                    <td className={`p-1 border text-center font-bold ${isPrint ? 'bg-gray-100' : 'bg-blue-50'}`} style={{ borderColor: commonStyles.tableBorderColor }}>{toPersianDigits(subject.average?.toFixed(2))}</td>
                </tr>
            ))}
        </tbody>
    </table>
  );

  const SubjectChart = ({height}: {height: number}) => (
    <>
        <h3 className="text-md font-bold text-center mb-1">نمودار میانگین دروس</h3>
        <ResponsiveContainer width="100%" height={height}>
        <BarChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 40 }} animationDuration={0}>
                <CartesianGrid strokeDasharray="3 3" stroke={commonStyles.gridStrokeColor} />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={45} interval={0} tick={{ fontSize: 8, fill: commonStyles.tickFillColor }}/>
                <YAxis type="number" domain={[0, 20]} tick={{ fontSize: 9, fill: commonStyles.tickFillColor }} tickFormatter={toPersianDigits}/>
                <Tooltip contentStyle={tooltipStyle} formatter={(value: number) => toPersianDigits(value.toFixed(2))} />
                <Bar dataKey="میانگین" fill={commonStyles.barFillColor} barSize={10} />
            </BarChart>
        </ResponsiveContainer>
    </>
  );

  // Templates
  const renderDefaultTemplate = () => {
    return (
        <div className={`flex-1 ${orientation === 'landscape' ? 'grid grid-cols-2 gap-x-4 items-start' : 'flex flex-col'}`}>
            <div className="flex-1 overflow-auto">
                <h3 className="text-md font-bold my-2 text-center">جدول نمرات</h3>
                <FullGradesTable />
            </div>
            {showChart && (
                <div className={`${orientation === 'landscape' ? '' : 'mt-4'}`}>
                    <SubjectChart height={chartHeight} />
                </div>
            )}
        </div>
    );
  };
  
  const renderModernTemplate = () => {
    return (
        <div className={`flex-1 ${orientation === 'landscape' ? 'grid grid-cols-3 gap-x-4' : 'flex flex-col'}`}>
            <div className={`p-3 rounded-lg ${isPrint ? 'bg-gray-100 border' : 'bg-gray-50 border'} ${orientation === 'landscape' ? '' : 'mb-4'}`}>
                 <h3 className="text-lg font-bold text-center mb-4 border-b pb-2" style={{borderColor: commonStyles.tableBorderColor}}>خلاصه وضعیت</h3>
                 <div className="text-center mb-4">
                    <p className="text-sm">معدل کل</p>
                    <p className={`text-4xl font-bold ${isPrint ? 'text-blue-700' : 'text-blue-600'}`}>{toPersianDigits(student.totalAverage?.toFixed(2))}</p>
                 </div>
                 {showRank && (
                    <div className="text-center mb-4">
                       <p className="text-sm">رتبه کلاسی</p>
                       <p className={`text-4xl font-bold ${isPrint ? 'text-green-700' : 'text-green-600'}`}>{toPersianDigits(student.rank)}</p>
                    </div>
                 )}
                 <h4 className="text-md font-bold mt-6 mb-2">یادداشت مدیر</h4>
                 <p className="text-xs italic">{schoolInfo.principalMessage}</p>
            </div>
            <div className={`${orientation === 'landscape' ? 'col-span-2 flex flex-col' : ''}`}>
                <h3 className="text-md font-bold my-2 text-center">جدول نمرات</h3>
                <div className="flex-shrink-0 overflow-auto">
                    <FullGradesTable />
                </div>
                {showChart && (
                    <div className="mt-4 flex-grow">
                        <SubjectChart height={chartHeight} />
                    </div>
                )}
            </div>
        </div>
    );
  };
  
  const renderFormalTemplate = () => {
    return (
        <div className="flex-1 flex flex-col">
             <h3 className="text-md font-bold my-2 text-center">جدول نمرات</h3>
            <div className="overflow-auto">
                <FullGradesTable />
            </div>
            <div className="flex justify-between items-stretch mt-4 gap-x-4">
                 <div className={`flex-1 border p-2 rounded-md ${isPrint ? 'bg-gray-100' : 'bg-gray-50'}`} style={{ borderColor: commonStyles.tableBorderColor }}>
                    <h4 className={`text-sm font-bold mb-1`}>یادداشت مدیر:</h4>
                    <p className={`text-xs`}>{schoolInfo.principalMessage}</p>
                </div>
                <div className={`w-1/3 border p-2 rounded-lg flex flex-col justify-center items-center text-center ${isPrint ? 'bg-gray-200 border-black' : 'bg-green-100 border-green-500'}`}>
                    <div>
                        <span className={`block text-md font-semibold`}>معدل کل</span>
                        <span className={`block text-2xl font-bold`}>{toPersianDigits(student.totalAverage?.toFixed(2))}</span>
                    </div>
                    {showRank && (
                        <>
                            <div className={`border-b w-full my-1 ${isPrint ? 'border-black' : 'border-green-300'}`}></div>
                            <div>
                                <span className={`block text-md font-semibold`}>رتبه</span>
                                <span className={`block text-2xl font-bold`}>{toPersianDigits(student.rank)}</span>
                            </div>
                        </>
                    )}
                </div>
            </div>
             {showChart && (
                <div className="mt-4">
                   <SubjectChart height={chartHeight} />
                </div>
            )}
        </div>
    );
  };

  const renderContent = () => {
      switch(template) {
          case 'modern': return renderModernTemplate();
          case 'formal': return renderFormalTemplate();
          case 'default':
          default:
            return renderDefaultTemplate();
      }
  };

  return (
    <div className={`${dimensionClasses} p-6 shadow-2xl flex flex-col mx-auto text-[11px] transition-colors duration-300 ${isPrint ? 'bg-white text-black border-2 border-black' : 'bg-white text-gray-800'}`}>
      <header className={`text-center border-b-2 pb-2 mb-3 ${isPrint ? 'border-black' : 'border-gray-400'}`}>
        <h1 className={`text-2xl font-bold`}>{schoolInfo.reportCardTitle}</h1>
        <h2 className={`text-lg font-semibold ${isPrint ? 'text-gray-700' : 'text-gray-600'}`}>{schoolInfo.name}</h2>
      </header>

      <div className="grid grid-cols-6 gap-x-4 gap-y-1 text-sm mb-3">
        <div className="col-span-3"><strong>نام:</strong> {firstName}</div>
        <div className="col-span-3"><strong>نام خانوادگی:</strong> {lastName}</div>
        <div className="col-span-2"><strong>پایه:</strong> {schoolInfo.gradeLevel}</div>
        <div className="col-span-2"><strong>کلاس:</strong> {className}</div>
        <div className="col-span-2"><strong>سال تحصیلی:</strong> {toPersianDigits(schoolInfo.academicYear)}</div>
      </div>
      
      <div className="flex-grow flex flex-col overflow-hidden">
        {renderContent()}
      </div>
      
      <SignatureSection signatures={enabledSignatures} />
      
      <footer className={`text-center text-xs pt-3 mt-2 ${isPrint ? 'text-gray-600 border-t-2 border-black' : 'text-gray-500 border-t'}`}>
        تاریخ صدور: {new Date().toLocaleDateString('fa-IR')}
      </footer>
    </div>
  );
};

export default ReportCard;