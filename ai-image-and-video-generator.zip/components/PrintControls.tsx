import React, { useState, useEffect } from 'react';
import { Printer, FileSymlink, ChevronsRightLeft } from 'lucide-react';

type PaperSize = 'a4' | 'a5';
type Orientation = 'portrait' | 'landscape';

interface Props {
  printAreaId: string;
}

const PrintControls: React.FC<Props> = ({ printAreaId }) => {
  const [paperSize, setPaperSize] = useState<PaperSize>('a4');
  const [orientation, setOrientation] = useState<Orientation>('portrait');

  const handlePrint = () => {
    let style = document.getElementById('print-settings-style');
    if (!style) {
        style = document.createElement('style');
        style.id = 'print-settings-style';
        document.head.appendChild(style);
    }
    style.innerHTML = `@media print { @page { size: ${paperSize} ${orientation}; margin: 1cm; } }`;
    
    // Temporarily set the ID for printing
    const printElement = document.getElementById(printAreaId);
    if (printElement) {
        const originalId = printElement.id;
        printElement.id = 'print-area'; // The generic ID our CSS looks for
        window.print();
        printElement.id = originalId; // Restore original ID after print dialog
    } else {
        console.error(`Print area with ID "${printAreaId}" not found.`);
    }
  };

  useEffect(() => {
    // Cleanup style on component unmount
    return () => {
        const style = document.getElementById('print-settings-style');
        if (style) {
            style.remove();
        }
    }
  }, []);

  return (
    <div className="flex items-center gap-x-2">
        <div className="flex items-center gap-x-1">
            <FileSymlink size={16} className="text-gray-500" />
            <select value={paperSize} onChange={e => setPaperSize(e.target.value as PaperSize)} className="p-1 text-sm border border-gray-300 bg-white text-gray-700 rounded-md">
                <option value="a4">A4</option>
                <option value="a5">A5</option>
            </select>
        </div>
        <div className="flex items-center gap-x-1">
            <ChevronsRightLeft size={16} className="text-gray-500" />
            <select value={orientation} onChange={e => setOrientation(e.target.value as Orientation)} className="p-1 text-sm border border-gray-300 bg-white text-gray-700 rounded-md">
                <option value="portrait">عمودی</option>
                <option value="landscape">افقی</option>
            </select>
        </div>
        <button
            onClick={handlePrint}
            className="flex items-center gap-x-2 bg-blue-600 text-white px-3 py-2 rounded-md hover:bg-blue-700 transition-colors"
        >
            <Printer size={18} />
            <span className="text-sm">چاپ</span>
        </button>
    </div>
  );
};

export default PrintControls;