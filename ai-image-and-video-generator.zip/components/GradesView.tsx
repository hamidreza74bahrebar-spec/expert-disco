import React, { useRef, useState } from 'react';
import { EnrichedStudentData, Student, Subject } from '../types';
import { NUM_GRADES_PER_SUBJECT } from '../constants';
import { v4 as uuidv4 } from 'uuid';
import { UserPlus, Trash2, FileDown, FileUp, PlusCircle, BarChartHorizontal, Users } from 'lucide-react';
import EditableField from './EditableField';
import PrintControls from './PrintControls';
import SubjectDistributionChartModal from './SubjectDistributionChartModal';
import BulkAddStudentModal from './BulkAddStudentModal';
import { toPersianDigits } from '../services/calculationService';

interface Props {
  students: EnrichedStudentData[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  subjectNames: string[];
  onSubjectNameChange: (subjectIndex: number, newName: string) => void;
  onAddSubject: (subjectName: string) => void;
  onDeleteSubject: (subjectName: string) => void;
  subjectInclusion: { [subjectName: string]: boolean };
  onSubjectInclusionChange: (subjectName: string, isIncluded: boolean) => void;
  onStudentInclusionChange: (studentId: string, isIncluded: boolean) => void;
}

const GradesView: React.FC<Props> = ({ students, setStudents, subjectNames, onSubjectNameChange, onAddSubject, onDeleteSubject, subjectInclusion, onSubjectInclusionChange, onStudentInclusionChange }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [subjectToDelete, setSubjectToDelete] = useState<string>('');
  const [chartModalSubject, setChartModalSubject] = useState<string | null>(null);
  const [isBulkAddModalOpen, setIsBulkAddModalOpen] = useState(false);

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedText = e.clipboardData.getData('text');
    const target = e.target as HTMLInputElement;
    const { row, col } = target.dataset;

    const startRow = parseInt(row || '0', 10);
    const startCol = parseInt(col || '0', 10);

    const rows = pastedText.split(/\r\n|\n/).filter(line => line.trim() !== '').map(line => line.split('\t'));
    if (rows.length === 0) return;

    setStudents(currentStudents => {
        let newStudents: Student[] = JSON.parse(JSON.stringify(currentStudents));

        if (startCol === 0) {
            const requiredStudentCount = startRow + rows.length;
            const studentsToAddCount = requiredStudentCount - newStudents.length;

            if (studentsToAddCount > 0) {
                const studentsToAdd: Student[] = [];
                for (let i = 0; i < studentsToAddCount; i++) {
                    const newStudent: Student = {
                        id: uuidv4(),
                        name: 'دانش‌آموز جدید',
                        subjects: subjectNames.map(name => ({
                            name,
                            grades: Array(NUM_GRADES_PER_SUBJECT).fill(null)
                        })),
                        includeInReportCard: true,
                    };
                    studentsToAdd.push(newStudent);
                }
                newStudents.push(...studentsToAdd);
            }
        }

        rows.forEach((rowData, rowIndex) => {
            const currentStudentIndex = startRow + rowIndex;
            if (currentStudentIndex >= newStudents.length) return;

            rowData.forEach((cellData, colIndex) => {
                const currentGridCol = startCol + colIndex;
                const value = cellData.trim();

                if (currentGridCol === 0) {
                    if (value) newStudents[currentStudentIndex].name = value;
                } 
                else {
                    const baseCol = currentGridCol - 1;
                    const colsPerSubject = NUM_GRADES_PER_SUBJECT + 1;
                    const subjectIndex = Math.floor(baseCol / colsPerSubject);
                    const gradeIndex = baseCol % colsPerSubject;

                    if (subjectIndex < subjectNames.length && gradeIndex < NUM_GRADES_PER_SUBJECT) {
                         const newGrade = value === '' ? null : parseFloat(value.replace(',', '.')); // Also handle comma as decimal separator
                         if (value === '' || (!isNaN(newGrade) && newGrade >= 0 && newGrade <= 20)) {
                             newStudents[currentStudentIndex].subjects[subjectIndex].grades[gradeIndex] = newGrade;
                         }
                    }
                }
            });
        });

        return newStudents;
    });
};

  const handleGradeChange = (studentId: string, subjectIndex: number, gradeIndex: number, value: string) => {
    const newGrade = value === '' ? null : parseFloat(value);
    if (value !== '' && (isNaN(newGrade) || newGrade < 0 || newGrade > 20)) return;

    setStudents(prev => prev.map(student => {
      if (student.id === studentId) {
        const newSubjects = [...student.subjects];
        newSubjects[subjectIndex].grades[gradeIndex] = newGrade;
        return { ...student, subjects: newSubjects };
      }
      return student;
    }));
  };

  const handleSubjectAverageChange = (studentId: string, subjectIndex: number, value: string) => {
    const newAverage = value === '' ? null : parseFloat(value);
    if (value !== '' && (isNaN(newAverage) || newAverage < 0 || newAverage > 20)) return;

    setStudents(prev => prev.map(student => {
      if (student.id === studentId) {
        const newSubjects = [...student.subjects];
        const newGrades = Array(NUM_GRADES_PER_SUBJECT).fill(newAverage);
        newSubjects[subjectIndex] = {
            ...newSubjects[subjectIndex],
            grades: newGrades,
        };
        return { ...student, subjects: newSubjects };
      }
      return student;
    }));
  };

  const handleNameChange = (studentId: string, newName: string) => {
    setStudents(prev => prev.map(student => 
      student.id === studentId ? { ...student, name: newName } : student
    ));
  };
  
  const addStudent = () => {
    const newStudent: Student = {
        id: uuidv4(),
        name: 'دانش‌آموز جدید',
        subjects: subjectNames.map(name => ({
            name,
            grades: Array(NUM_GRADES_PER_SUBJECT).fill(null)
        })),
        includeInReportCard: true,
    };
    setStudents(prev => [...prev, newStudent]);
  };

  const handleBulkAddStudents = (names: string[]) => {
    const newStudents: Student[] = names.map(name => ({
        id: uuidv4(),
        name,
        subjects: subjectNames.map(sName => ({
            name: sName,
            grades: Array(NUM_GRADES_PER_SUBJECT).fill(null)
        })),
        includeInReportCard: true,
    }));
    setStudents(prev => [...prev, ...newStudents]);
    setIsBulkAddModalOpen(false);
  };

  const removeStudent = (studentId: string) => {
    setStudents(prev => prev.filter(student => student.id !== studentId));
  };
  
  const handleAddSubjectClick = () => {
    const newName = window.prompt("لطفاً نام درس جدید را وارد کنید:");
    if (newName) {
        onAddSubject(newName);
    }
  };

  const handleDeleteSubjectClick = () => {
    if (subjectNames.length > 0) {
        setSubjectToDelete(subjectNames[0]); // pre-select first subject
        setIsDeleteModalOpen(true);
    } else {
        alert("درسی برای حذف وجود ندارد.");
    }
  };

  const confirmDeleteSubject = () => {
    if (subjectToDelete) {
        onDeleteSubject(subjectToDelete);
        setIsDeleteModalOpen(false);
        setSubjectToDelete('');
    }
  };

  const handleDownloadExcel = () => {
    let csvContent = "\uFEFF"; // BOM for Excel UTF-8 support

    // Create Header Row
    const headers = ['ID', 'نام دانش‌آموز'];
    subjectNames.forEach(subjectName => {
        for (let i = 1; i <= NUM_GRADES_PER_SUBJECT; i++) {
            headers.push(`${subjectName} - نمره ${i}`);
        }
    });
    csvContent += headers.join(',') + '\r\n';

    // Create Data Rows
    students.forEach(student => {
        const rowData = [student.id, student.name];
        const studentGrades = subjectNames.flatMap(subjectName => {
          const subject = student.subjects.find(s => s.name === subjectName);
          const grades = subject ? subject.grades : Array(NUM_GRADES_PER_SUBJECT).fill(null);
          return grades.map(grade => (grade !== null ? String(grade) : ''));
        });
        rowData.push(...studentGrades);
        csvContent += rowData.join(',') + '\r\n';
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const date = new Date().toLocaleDateString('fa-IR', { year: 'numeric', month: '2-digit', day: '2-digit' }).replace(/\//g, '-');
    link.setAttribute("href", url);
    link.setAttribute("download", `نمرات-قالب-${date}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const csv = event.target?.result as string;
            const lines = csv.split(/\r\n|\n/).filter(line => line.trim() !== '');
            if (lines.length < 2) {
                throw new Error("فایل CSV خالی است یا فقط دارای سربرگ است.");
            }

            const header = lines[0].split(',').map(h => h.trim());
            const expectedHeaderStart = ['ID', 'نام دانش‌آموز'];
            if (header[0] !== expectedHeaderStart[0] || header[1] !== expectedHeaderStart[1]) {
                 throw new Error("فرمت سربرگ فایل CSV معتبر نیست. لطفاً از فایل دانلود شده به عنوان قالب استفاده کنید.");
            }
            
            const importedSubjectNamesFromHeader: string[] = [];
            for (let i = 2; i < header.length; i += NUM_GRADES_PER_SUBJECT) {
                const subjectCell = header[i] || '';
                const subjectName = subjectCell.substring(0, subjectCell.lastIndexOf(' - '));
                if (subjectName) {
                    importedSubjectNamesFromHeader.push(subjectName);
                }
            }
        
            if (importedSubjectNamesFromHeader.length !== subjectNames.length || 
                !importedSubjectNamesFromHeader.every((name, i) => name === subjectNames[i])) {
                throw new Error("ساختار دروس در فایل CSV با ساختار فعلی برنامه مطابقت ندارد. لطفاً ابتدا یک فایل اکسل جدید دانلود کرده و از آن به عنوان قالب استفاده کنید.");
            }

            const importedStudents: Student[] = [];
            for (let i = 1; i < lines.length; i++) {
                const values = lines[i].split(',');
                const id = values[0];
                const name = values[1];
                
                if (!id || !name) continue;

                const subjects: Subject[] = [];
                for (let s = 0; s < subjectNames.length; s++) {
                    const subjectGrades: (number | null)[] = [];
                    for (let g = 0; g < NUM_GRADES_PER_SUBJECT; g++) {
                        const gradeIndexInCsv = 2 + (s * NUM_GRADES_PER_SUBJECT) + g;
                        const gradeStr = values[gradeIndexInCsv];
                        const grade = (gradeStr && gradeStr.trim() !== '') ? parseFloat(gradeStr) : null;
                        
                        if (gradeStr && gradeStr.trim() !== '' && (isNaN(grade) || grade < 0 || grade > 20)) {
                             subjectGrades.push(null);
                        } else {
                             subjectGrades.push(grade);
                        }
                    }
                    subjects.push({
                        name: subjectNames[s],
                        grades: subjectGrades
                    });
                }
                importedStudents.push({ id, name, subjects, includeInReportCard: true });
            }
            
            setStudents(currentStudents => {
                // FIX: Explicitly type studentMap to help TypeScript infer the correct type for existingStudent.
                const studentMap: Map<string, Student> = new Map(currentStudents.map(s => [s.id, s]));
                importedStudents.forEach(importedStudent => {
                    const existingStudent = studentMap.get(importedStudent.id);
                    // Preserve existing includeInReportCard status if student already exists
                    importedStudent.includeInReportCard = existingStudent?.includeInReportCard ?? true;
                    studentMap.set(importedStudent.id, importedStudent);
                });
                return Array.from(studentMap.values());
            });
            alert("نمرات با موفقیت بارگذاری شدند!");

        } catch (error: any) {
            console.error("Error importing CSV:", error);
            alert(`خطا در بارگذاری فایل: ${error.message}`);
        } finally {
           if(e.target) e.target.value = '';
        }
    };
    reader.onerror = () => {
        alert("خطا در خواندن فایل.");
        if(e.target) e.target.value = '';
    };
    reader.readAsText(file, 'UTF-8');
  };
  
  const handleTableKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) return;
    e.preventDefault();

    const target = e.target as HTMLInputElement;
    const { row, col } = target.dataset;
    const currentRow = parseInt(row || '0', 10);
    const currentCol = parseInt(col || '0', 10);

    let nextRow = currentRow, nextCol = currentCol;

    if (e.key === 'ArrowUp') nextRow = Math.max(0, currentRow - 1);
    if (e.key === 'ArrowDown') nextRow = Math.min(students.length - 1, currentRow + 1);
    if (e.key === 'ArrowLeft') nextCol = Math.max(0, currentCol - 1);
    if (e.key === 'ArrowRight') {
        const maxCols = 1 + subjectNames.length * (NUM_GRADES_PER_SUBJECT + 1);
        nextCol = Math.min(maxCols - 1, currentCol + 1);
    }
    
    const nextEl = document.querySelector(`input[data-row='${nextRow}'][data-col='${nextCol}']`) as HTMLInputElement;

    if (nextEl) {
        nextEl.focus();
        nextEl.select();
    }
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
      <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
        <h2 className="text-2xl font-bold text-gray-800">ورود نمرات</h2>
        <div className="flex items-center gap-x-2 flex-wrap">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".csv"
              className="hidden"
            />
            <button onClick={handleImportClick} className="flex items-center gap-x-2 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors">
                <FileUp size={18} />
                بارگذاری
            </button>
            <button onClick={handleDownloadExcel} className="flex items-center gap-x-2 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors">
                <FileDown size={18} />
                دانلود
            </button>
            <div className="border-l h-6 border-gray-300 mx-2"></div>
            <PrintControls printAreaId="grades-print-area" />
            <div className="border-l h-6 border-gray-300 mx-2"></div>
            <button onClick={() => setIsBulkAddModalOpen(true)} className="flex items-center gap-x-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors">
                <Users size={18} />
                افزودن گروهی
            </button>
            <button onClick={addStudent} className="flex items-center gap-x-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors">
                <UserPlus size={18} />
                افزودن دانش‌آموز
            </button>
            <button onClick={handleAddSubjectClick} className="flex items-center gap-x-2 bg-teal-500 text-white px-4 py-2 rounded-md hover:bg-teal-600 transition-colors">
                <PlusCircle size={18} />
                افزودن درس
            </button>
            <button onClick={handleDeleteSubjectClick} className="flex items-center gap-x-2 bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition-colors">
                <Trash2 size={18} />
                حذف درس
            </button>
        </div>
      </div>
      <div id="grades-print-area">
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-center border-collapse">
            <thead className="bg-gray-100 sticky top-0">
                <tr>
                <th className="p-2 border border-gray-300 font-semibold" rowSpan={2}>نام دانش‌آموز</th>
                <th className="p-2 border border-gray-300 font-semibold" rowSpan={2} style={{minWidth: '110px'}}>فعال در کارنامه</th>
                {subjectNames.map((name, sIndex) => (
                    <th key={sIndex} className="p-0 border border-gray-300 font-semibold" colSpan={NUM_GRADES_PER_SUBJECT + 1}>
                    <div className="flex flex-col items-center justify-center pt-2">
                        <div className="flex items-center">
                            <EditableField
                                as="div"
                                initialValue={name}
                                onSave={(newValue) => onSubjectNameChange(sIndex, newValue)}
                                className="p-1"
                                inputClassName="w-full p-1 text-center font-semibold bg-gray-200 rounded-md"
                            />
                            <button onClick={() => setChartModalSubject(name)} title={`تحلیل نمرات ${name}`} className="p-1 text-gray-500 hover:text-blue-600">
                                <BarChartHorizontal size={14} />
                            </button>
                        </div>
                        <div className="flex items-center space-i-1 my-1 cursor-pointer select-none" onClick={() => onSubjectInclusionChange(name, !subjectInclusion[name])}>
                                <div className={`w-9 h-5 flex items-center rounded-full p-1 transition-colors ${subjectInclusion[name] ? 'bg-blue-600' : 'bg-gray-400'}`}>
                                    <div className={`bg-white w-3 h-3 rounded-full shadow-md transform transition-transform ${subjectInclusion[name] ? 'translate-x-4' : ''}`}></div>
                                </div>
                                <span className={`text-xs font-normal ${subjectInclusion[name] ? 'text-blue-700' : 'text-gray-500'}`}>
                                    {subjectInclusion[name] ? 'محاسبه در معدل' : 'عدم محاسبه'}
                                </span>
                        </div>
                    </div>
                    </th>
                ))}
                <th className="p-2 border border-gray-300 font-semibold" rowSpan={2}>معدل کل</th>
                <th className="p-2 border border-gray-300 font-semibold" rowSpan={2}>رتبه</th>
                <th className="p-2 border border-gray-300 font-semibold" rowSpan={2}>عملیات</th>
                </tr>
                <tr>
                {subjectNames.flatMap((_, sIndex) => [
                    ...Array.from({ length: NUM_GRADES_PER_SUBJECT }).map((_, gIndex) => (
                    <th key={`${sIndex}-${gIndex}`} className="p-2 border border-gray-300 font-semibold text-xs">{`نمره ${toPersianDigits(gIndex + 1)}`}</th>
                    )),
                    <th key={`avg-${sIndex}`} className="p-2 border border-gray-300 font-semibold bg-blue-50 text-xs">میانگین درس</th>
                ])}
                </tr>
            </thead>
            <tbody>
                {students.map((student, studentIndex) => (
                <tr key={student.id} className="hover:bg-gray-50">
                    <td className="p-1 border border-gray-300">
                    <input
                        type="text"
                        value={student.name}
                        onChange={(e) => handleNameChange(student.id, e.target.value)}
                        onPaste={handlePaste}
                        onKeyDown={handleTableKeyDown}
                        data-row={studentIndex}
                        data-col={0}
                        className="w-32 p-1 text-center bg-transparent focus:bg-blue-50 focus:ring-1 rounded"
                    />
                    </td>
                    <td className="p-1 border border-gray-300 text-center">
                        <div className="flex justify-center items-center">
                            <div className="flex items-center space-i-1 cursor-pointer select-none" title="فعال یا غیرفعال کردن دانش‌آموز در رتبه‌بندی و کارنامه" onClick={() => onStudentInclusionChange(student.id, !student.includeInReportCard)}>
                                <div className={`w-10 h-6 flex items-center rounded-full p-1 transition-colors ${student.includeInReportCard ? 'bg-green-500' : 'bg-gray-400'}`}>
                                    <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${student.includeInReportCard ? 'translate-x-4' : ''}`}></div>
                                </div>
                            </div>
                        </div>
                    </td>
                    {student.subjects.map((subject, sIndex) => [
                    ...subject.grades.map((grade, gIndex) => (
                        <td key={`${sIndex}-${gIndex}`} className="p-1 border border-gray-300">
                        <input
                            type="number"
                            step="0.01"
                            min="0"
                            max="20"
                            value={grade ?? ''}
                            onChange={(e) => handleGradeChange(student.id, sIndex, gIndex, e.target.value)}
                            onPaste={handlePaste}
                            onKeyDown={handleTableKeyDown}
                            data-row={studentIndex}
                            data-col={1 + sIndex * (NUM_GRADES_PER_SUBJECT + 1) + gIndex}
                            className="w-16 p-1 text-center bg-transparent focus:bg-blue-50 focus:ring-1 rounded"
                        />
                        </td>
                    )),
                    <td key={`avg-${sIndex}`} className="p-1 border border-gray-300 bg-blue-50">
                        <input
                        type="text"
                        readOnly
                        value={toPersianDigits(subject.average?.toFixed(2))}
                        className="w-20 p-1 text-center font-semibold bg-transparent focus:bg-blue-50 focus:ring-1 rounded"
                        />
                    </td>
                    ])}
                    <td className={`p-2 border border-gray-300 font-bold ${student.includeInReportCard ? 'bg-green-50 text-green-700' : 'bg-gray-100 text-gray-400'}`}>
                    {toPersianDigits(student.totalAverage?.toFixed(2))}
                    </td>
                    <td className={`p-2 border border-gray-300 font-bold ${student.includeInReportCard ? 'bg-yellow-50 text-yellow-700' : 'bg-gray-100 text-gray-400'}`}>{toPersianDigits(student.rank)}</td>
                    <td className="p-2 border border-gray-300">
                    <button onClick={() => removeStudent(student.id)} className="text-red-500 hover:text-red-700 p-1">
                        <Trash2 size={18} />
                    </button>
                    </td>
                </tr>
                ))}
            </tbody>
            </table>
        </div>
      </div>
      {isDeleteModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-20">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md border border-gray-300 text-gray-700">
                <h3 className="text-lg font-bold mb-4 text-gray-900">حذف درس</h3>
                <p className="mb-4 text-gray-600">
                    لطفاً درسی که می‌خواهید حذف کنید را انتخاب نمایید. این عمل تمام نمرات مربوط به این درس را برای همه دانش‌آموزان پاک خواهد کرد و قابل بازگشت نیست.
                </p>
                <select
                    value={subjectToDelete}
                    onChange={(e) => setSubjectToDelete(e.target.value)}
                    className="w-full p-2 border border-gray-300 bg-white text-gray-800 rounded-md mb-6"
                >
                    {subjectNames.map(name => (
                        <option key={name} value={name}>{name}</option>
                    ))}
                </select>
                <div className="flex justify-end gap-x-3">
                    <button onClick={() => setIsDeleteModalOpen(false)} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                        انصراف
                    </button>
                    <button onClick={confirmDeleteSubject} className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
                        حذف نهایی
                    </button>
                </div>
            </div>
        </div>
     )}
     {chartModalSubject && (
        <SubjectDistributionChartModal
            isOpen={!!chartModalSubject}
            onClose={() => setChartModalSubject(null)}
            subjectName={chartModalSubject}
            students={students}
        />
     )}
     <BulkAddStudentModal
        isOpen={isBulkAddModalOpen}
        onClose={() => setIsBulkAddModalOpen(false)}
        onConfirm={handleBulkAddStudents}
     />
    </div>
  );
};

export default GradesView;