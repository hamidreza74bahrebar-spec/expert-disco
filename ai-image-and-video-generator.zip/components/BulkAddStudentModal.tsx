import React, { useState } from 'react';
import { UserPlus, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (names: string[]) => void;
}

const BulkAddStudentModal: React.FC<Props> = ({ isOpen, onClose, onConfirm }) => {
  const [names, setNames] = useState('');

  if (!isOpen) return null;

  const handleConfirmClick = () => {
    const nameList = names.split('\n').map(name => name.trim()).filter(name => name !== '');
    if (nameList.length === 0) {
        alert('لطفاً حداقل یک نام وارد کنید.');
        return;
    }
    onConfirm(nameList);
    setNames('');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50" onClick={onClose}>
      <div className="bg-white text-gray-800 border border-gray-300 rounded-lg shadow-2xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center border-b border-gray-200 pb-3 mb-4">
          <h2 className="text-xl font-bold text-gray-900">افزودن گروهی دانش‌آموزان</h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 hover:text-gray-800">
            <X size={24} />
          </button>
        </div>

        <p className="text-gray-600 mb-4">
          اسامی دانش‌آموزان را در کادر زیر وارد کنید. هر نام باید در یک خط جداگانه قرار گیرد.
        </p>

        <textarea
          value={names}
          onChange={(e) => setNames(e.target.value)}
          placeholder={'علی رضایی\nمریم احمدی\nرضا حسینی'}
          className="w-full h-48 p-2 border border-gray-300 bg-white text-gray-800 rounded-md focus:ring-2 focus:ring-blue-500 resize-y"
        />

        <div className="flex justify-end gap-x-3 mt-6">
            <button onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                انصراف
            </button>
            <button onClick={handleConfirmClick} className="flex items-center gap-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
              <UserPlus size={18} />
              افزودن دانش‌آموزان
            </button>
        </div>
      </div>
    </div>
  );
};

export default BulkAddStudentModal;