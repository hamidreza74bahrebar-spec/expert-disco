import React, { useState, KeyboardEvent, FocusEvent, useRef, useEffect } from 'react';

interface Props {
  initialValue: string;
  onSave: (newValue: string) => void;
  className?: string;
  inputClassName?: string;
  as?: 'h1' | 'h2' | 'h3' | 'th' | 'span' | 'p' | 'div';
}

const EditableField: React.FC<Props> = ({ initialValue, onSave, className, inputClassName, as = 'span' }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [value, setValue] = useState(initialValue);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  useEffect(() => {
    if (isEditing) {
      inputRef.current?.focus();
      inputRef.current?.select();
    }
  }, [isEditing]);

  const handleSave = () => {
    if (value.trim() !== '' && value.trim() !== initialValue) {
      onSave(value.trim());
    } else {
      setValue(initialValue); // Revert if empty or unchanged
    }
    setIsEditing(false);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      setValue(initialValue);
      setIsEditing(false);
    }
  };

  const handleBlur = (e: FocusEvent<HTMLInputElement>) => {
    handleSave();
  };

  const Tag = as;

  if (isEditing) {
    return (
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        className={inputClassName || className}
      />
    );
  }

  return (
    <Tag className={`${className} transition-colors duration-200 hover:bg-gray-200/50`} onClick={() => setIsEditing(true)} style={{ cursor: 'pointer' }}>
      {initialValue}
    </Tag>
  );
};

export default EditableField;