import React, { useState } from 'react';
import { Save, X } from 'lucide-react';

interface Font {
  name: string;
  value: string;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (font: Font) => void;
  existingFonts: Font[];
}

const AddFontModal: React.FC<Props> = ({ isOpen, onClose, onSave, existingFonts }) => {
  const [name, setName] = useState('');
  const [value, setValue] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSave = () => {
    const trimmedName = name.trim();
    const trimmedValue = value.trim();

    if (!trimmedName || !trimmedValue) {
      setError('نام فونت و مقدار CSS نمی‌توانند خالی باشند.');
      return;
    }
    
    if (existingFonts.some(f => f.name.toLowerCase() === trimmedName.toLowerCase())) {
        setError('فونت با این نام از قبل وجود دارد.');
        return;
    }

    onSave({ name: trimmedName, value: trimmedValue });
    setName('');
    setValue('');
    setError('');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50" onClick={onClose}>
      <div className="bg-white text-gray-800 border border-gray-300 rounded-lg shadow-2xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center border-b border-gray-200 pb-3 mb-4">
          <h2 className="text-xl font-bold text-gray-900">افزودن فونت جدید</h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 hover:text-gray-900">
            <X size={24} />
          </button>
        </div>

        <p className="text-gray-600 mb-4 text-sm">
          نام نمایشی فونت و مقدار معتبر CSS برای <code className="bg-gray-200 p-1 rounded text-xs">font-family</code> را وارد کنید.
          توجه: فونت باید روی سیستم شما نصب باشد یا قبلاً در برنامه بارگذاری شده باشد.
        </p>

        <div className="space-y-4">
            <div>
                <label htmlFor="font-name" className="block text-sm font-medium text-gray-700 mb-1">نام فونت</label>
                <input
                    id="font-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثلاً: ایران سنس"
                    className="w-full p-2 border border-gray-300 bg-white text-gray-800 rounded-md focus:ring-2 focus:ring-blue-500"
                />
            </div>
            <div>
                <label htmlFor="font-value" className="block text-sm font-medium text-gray-700 mb-1">مقدار CSS</label>
                <input
                    id="font-value"
                    type="text"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    placeholder="'IRANSans', sans-serif"
                    className="w-full p-2 border border-gray-300 bg-white text-gray-800 rounded-md focus:ring-2 focus:ring-blue-500 font-mono text-left"
                    dir="ltr"
                />
            </div>
        </div>

        {error && <p className="text-red-500 text-sm mt-3">{error}</p>}

        <div className="flex justify-end gap-x-3 mt-6">
            <button onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                انصراف
            </button>
            <button onClick={handleSave} className="flex items-center gap-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
              <Save size={18} />
              ذخیره فونت
            </button>
        </div>
      </div>
    </div>
  );
};

export default AddFontModal;