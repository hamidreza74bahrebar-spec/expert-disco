import React, { useState } from 'react';
import { SchoolInfo, AppSettings } from '../types';
import { Building, GraduationCap, MessageSquare, FileText, CalendarDays, Palette, Type, Scale, UserCheck, Briefcase, PlusCircle, Trash2, BarChart2 } from 'lucide-react';
import { reportCardTemplates } from '../constants';
import AddFontModal from './AddFontModal';
import { toPersianDigits } from '../services/calculationService';

interface Props {
  schoolInfo: SchoolInfo;
  setSchoolInfo: React.Dispatch<React.SetStateAction<SchoolInfo>>;
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
}

const SettingsView: React.FC<Props> = ({ schoolInfo, setSchoolInfo, settings, setSettings }) => {
  const [isAddFontModalOpen, setIsAddFontModalOpen] = useState(false);

  const handleInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setSchoolInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleSettingsChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setSettings(prev => ({
        ...prev,
        [name]: name === 'baseFontSize' ? parseInt(value, 10) : value,
    }));
  };

  const handleSignatureChange = (index: number, field: 'name' | 'title', value: string) => {
    setSchoolInfo(prev => {
        const newSignatures = [...prev.signatures];
        newSignatures[index] = { ...newSignatures[index], [field]: value };
        return { ...prev, signatures: newSignatures };
    });
  };

  const handleSignatureToggle = (index: number, isEnabled: boolean) => {
    setSchoolInfo(prev => {
        const newSignatures = [...prev.signatures];
        newSignatures[index] = { ...newSignatures[index], enabled: isEnabled };
        return { ...prev, signatures: newSignatures };
    });
  };

  const handleAddFont = (font: { name: string; value: string }) => {
    setSettings(prev => ({
        ...prev,
        availableFonts: [...prev.availableFonts, font]
    }));
  };

  const handleDeleteFont = (fontValueToDelete: string) => {
    if (settings.availableFonts.length <= 1) {
        alert('حداقل یک فونت باید در برنامه وجود داشته باشد.');
        return;
    }
    
    setSettings(prev => {
        const newFonts = prev.availableFonts.filter(f => f.value !== fontValueToDelete);
        // If the deleted font was the active one, switch to the first available font
        const newFontFamilyBody = prev.fontFamilyBody === fontValueToDelete ? newFonts[0].value : prev.fontFamilyBody;
        const newFontFamilyHeading = prev.fontFamilyHeading === fontValueToDelete ? newFonts[0].value : prev.fontFamilyHeading;
        return {
            ...prev,
            availableFonts: newFonts,
            fontFamilyBody: newFontFamilyBody,
            fontFamilyHeading: newFontFamilyHeading,
        };
    });
  };

  return (
    <>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
                <h2 className="text-2xl font-bold mb-6 text-gray-800 border-b border-gray-300 pb-3">اطلاعات مدرسه</h2>
                <form className="space-y-6">
                    <div className="flex items-center space-i-4">
                    <Building className="text-blue-500" size={24} />
                    <label htmlFor="name" className="w-32 text-md font-semibold text-gray-600">نام دبیرستان</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={schoolInfo.name}
                        onChange={handleInfoChange}
                        className="flex-1 p-2 border border-gray-300 bg-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    </div>
                    <div className="flex items-center space-i-4">
                    <FileText className="text-blue-500" size={24} />
                    <label htmlFor="reportCardTitle" className="w-32 text-md font-semibold text-gray-600">عنوان کارنامه</label>
                    <input
                        type="text"
                        id="reportCardTitle"
                        name="reportCardTitle"
                        value={schoolInfo.reportCardTitle}
                        onChange={handleInfoChange}
                        className="flex-1 p-2 border border-gray-300 bg-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    </div>
                    <div className="flex items-center space-i-4">
                    <GraduationCap className="text-blue-500" size={24} />
                    <label htmlFor="gradeLevel" className="w-32 text-md font-semibold text-gray-600">پایه</label>
                    <input
                        type="text"
                        id="gradeLevel"
                        name="gradeLevel"
                        value={schoolInfo.gradeLevel}
                        onChange={handleInfoChange}
                        className="flex-1 p-2 border border-gray-300 bg-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    </div>
                    <div className="flex items-center space-i-4">
                    <CalendarDays className="text-blue-500" size={24} />
                    <label htmlFor="academicYear" className="w-32 text-md font-semibold text-gray-600">سال تحصیلی</label>
                    <input
                        type="text"
                        id="academicYear"
                        name="academicYear"
                        value={schoolInfo.academicYear}
                        onChange={handleInfoChange}
                        className="flex-1 p-2 border border-gray-300 bg-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    </div>
                    <div className="flex items-start space-i-4">
                    <MessageSquare className="text-blue-500 mt-2" size={24} />
                    <label htmlFor="principalMessage" className="w-32 text-md font-semibold text-gray-600 mt-2">پیام مدیر</label>
                    <textarea
                        id="principalMessage"
                        name="principalMessage"
                        value={schoolInfo.principalMessage}
                        onChange={handleInfoChange}
                        rows={4}
                        className="flex-1 p-2 border border-gray-300 bg-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    </div>
                </form>
                <h3 className="text-xl font-bold mt-8 mb-4 text-gray-800 border-t border-gray-300 pt-4">امضاها</h3>
                <div className="space-y-4">
                    {schoolInfo.signatures?.map((signature, index) => (
                        <div key={index} className="p-3 border border-gray-200 rounded-md bg-gray-50">
                            <div className="flex justify-between items-center mb-2">
                                <p className="font-semibold text-gray-700">امضای شماره {toPersianDigits(index + 1)}</p>
                                <div className="flex items-center space-i-1 cursor-pointer select-none" onClick={() => handleSignatureToggle(index, !signature.enabled)}>
                                    <span className={`text-xs font-normal ${signature.enabled ? 'text-blue-600' : 'text-gray-500'}`}>
                                        {signature.enabled ? 'نمایش در کارنامه' : 'عدم نمایش'}
                                    </span>
                                    <div className={`w-9 h-5 flex items-center rounded-full p-1 transition-colors ${signature.enabled ? 'bg-blue-600' : 'bg-gray-300'}`}>
                                        <div className={`bg-white w-3 h-3 rounded-full shadow-md transform transition-transform ${signature.enabled ? 'translate-x-4' : ''}`}></div>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center space-i-4 mb-2">
                                <UserCheck className="text-blue-500" size={20} />
                                <label htmlFor={`signature-name-${index}`} className="w-24 text-sm font-semibold text-gray-600">نام کامل</label>
                                <input
                                    type="text"
                                    id={`signature-name-${index}`}
                                    name={`signature-name-${index}`}
                                    value={signature.name}
                                    onChange={(e) => handleSignatureChange(index, 'name', e.target.value)}
                                    className="flex-1 p-2 border border-gray-300 bg-white rounded-md text-sm focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div className="flex items-center space-i-4">
                                <Briefcase className="text-blue-500" size={20} />
                                <label htmlFor={`signature-title-${index}`} className="w-24 text-sm font-semibold text-gray-600">سمت</label>
                                <input
                                    type="text"
                                    id={`signature-title-${index}`}
                                    name={`signature-title-${index}`}
                                    value={signature.title}
                                    onChange={(e) => handleSignatureChange(index, 'title', e.target.value)}
                                    className="flex-1 p-2 border border-gray-300 bg-white rounded-md text-sm focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
                <h2 className="text-2xl font-bold mb-6 text-gray-800 border-b border-gray-300 pb-3">تنظیمات ظاهری</h2>
                <form className="space-y-6">
                    <div className="flex items-center space-i-4">
                        <Type className="text-blue-500" size={24} />
                        <label htmlFor="fontFamilyBody" className="w-32 text-md font-semibold text-gray-600">فونت اصلی (متن‌ها)</label>
                        <select
                            id="fontFamilyBody"
                            name="fontFamilyBody"
                            value={settings.fontFamilyBody}
                            onChange={handleSettingsChange}
                            className="flex-1 p-2 border border-gray-300 bg-white rounded-md focus:ring-2 focus:ring-blue-500"
                        >
                            {settings.availableFonts.map(font => (
                                <option key={font.value} value={font.value} style={{ fontFamily: font.value }}>{font.name}</option>
                            ))}
                        </select>
                    </div>
                     <div className="flex items-center space-i-4">
                        <Type className="text-blue-500" size={24} />
                        <label htmlFor="fontFamilyHeading" className="w-32 text-md font-semibold text-gray-600">فونت عناوین</label>
                        <select
                            id="fontFamilyHeading"
                            name="fontFamilyHeading"
                            value={settings.fontFamilyHeading}
                            onChange={handleSettingsChange}
                            className="flex-1 p-2 border border-gray-300 bg-white rounded-md focus:ring-2 focus:ring-blue-500"
                        >
                            {settings.availableFonts.map(font => (
                                <option key={font.value} value={font.value} style={{ fontFamily: font.value }}>{font.name}</option>
                            ))}
                        </select>
                    </div>
                    <div className="flex items-center space-i-4">
                        <Scale className="text-blue-500" size={24} />
                        <label htmlFor="baseFontSize" className="w-32 text-md font-semibold text-gray-600">اندازه فونت</label>
                        <div className="flex-1 flex items-center gap-x-3">
                            <input
                                type="range"
                                id="baseFontSize"
                                name="baseFontSize"
                                min="12"
                                max="18"
                                step="1"
                                value={settings.baseFontSize}
                                onChange={handleSettingsChange}
                                className="w-full"
                            />
                            <span className="font-bold text-blue-600">{toPersianDigits(settings.baseFontSize)}px</span>
                        </div>
                    </div>
                    <div className="flex items-center space-i-4">
                        <Palette className="text-blue-500" size={24} />
                        <label htmlFor="reportCardTemplate" className="w-32 text-md font-semibold text-gray-600">قالب کارنامه</label>
                        <select
                            id="reportCardTemplate"
                            name="reportCardTemplate"
                            value={settings.reportCardTemplate}
                            onChange={handleSettingsChange}
                            className="flex-1 p-2 border border-gray-300 bg-white rounded-md focus:ring-2 focus:ring-blue-500"
                        >
                            {reportCardTemplates.map(template => (
                                <option key={template.value} value={template.value}>{template.name}</option>
                            ))}
                        </select>
                    </div>
                    <div className="flex items-center space-i-4">
                        <BarChart2 className="text-blue-500" size={24} />
                        <label className="w-32 text-md font-semibold text-gray-600">نمودار نمرات</label>
                        <div className="flex-1 flex items-center space-i-2 cursor-pointer select-none" onClick={() => setSettings(prev => ({ ...prev, showReportCardChart: !prev.showReportCardChart }))}>
                            <div className={`w-10 h-6 flex items-center rounded-full p-1 transition-colors ${settings.showReportCardChart ? 'bg-blue-600' : 'bg-gray-300'}`}>
                                <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${settings.showReportCardChart ? 'translate-x-4' : ''}`}></div>
                            </div>
                            <span className={`text-sm font-medium ${settings.showReportCardChart ? 'text-blue-700' : 'text-gray-500'}`}>
                                {settings.showReportCardChart ? 'نمایش در کارنامه' : 'عدم نمایش در کارنامه'}
                            </span>
                        </div>
                    </div>
                </form>

                <div className="mt-8 pt-6 border-t border-gray-300">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold text-gray-800">مدیریت فونت‌ها</h3>
                        <button onClick={() => setIsAddFontModalOpen(true)} className="flex items-center gap-x-2 text-sm bg-blue-600 text-white px-3 py-1.5 rounded-md hover:bg-blue-700">
                            <PlusCircle size={16} />
                            افزودن فونت
                        </button>
                    </div>
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                        {settings.availableFonts.map(font => (
                            <div key={font.value} className="flex items-center justify-between p-2 bg-gray-50 rounded-md border border-gray-200">
                                <div>
                                    <p className="font-semibold text-gray-700">{font.name}</p>
                                    <p className="text-xs text-gray-500 font-mono" dir="ltr">{font.value}</p>
                                </div>
                                <button
                                    onClick={() => handleDeleteFont(font.value)}
                                    disabled={settings.availableFonts.length <= 1}
                                    className="p-2 text-red-500 hover:bg-red-500/10 rounded-full disabled:text-gray-400 disabled:hover:bg-transparent disabled:cursor-not-allowed"
                                    title="حذف فونت"
                                >
                                    <Trash2 size={16} />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
        <AddFontModal
            isOpen={isAddFontModalOpen}
            onClose={() => setIsAddFontModalOpen(false)}
            onSave={handleAddFont}
            existingFonts={settings.availableFonts}
        />
    </>
  );
};

export default SettingsView;