import React from 'react';
import { SchoolInfo, EnrichedStudentData, AppSettings } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import SignatureSection from './SignatureSection';
import { toPersianDigits } from '../services/calculationService';
import { NUM_GRADES_PER_SUBJECT } from '../constants';

type PaperSize = 'a4' | 'a5';
type Orientation = 'portrait' | 'landscape';

interface Props {
  student: EnrichedStudentData;
  schoolInfo: SchoolInfo;
  className: string;
  paperSize: PaperSize;
  orientation: Orientation;
  settings: AppSettings;
}

const ComprehensiveReport: React.FC<Props> = ({ student, schoolInfo, className, paperSize, orientation, settings }) => {
  const dimensions = {
      a4: { portrait: 'w-[210mm] h-[297mm]', landscape: 'w-[297mm] h-[210mm]' },
      a5: { portrait: 'w-[148mm] h-[210mm]', landscape: 'w-[210mm] h-[148mm]' },
  };
  const dimensionClasses = dimensions[paperSize][orientation];
  
  const commonStyles = {
    gridStrokeColor: '#d1d5db',
    tickFillColor: '#1f2937',
    barFillColor: '#3b82f6',
    tableBorderColor: '#000000',
  };

  const tooltipStyle = {
    backgroundColor: '#ffffff',
    border: `1px solid ${commonStyles.tableBorderColor}`,
    color: '#1f2937',
    fontSize: '10px',
    padding: '2px 5px',
  };

  const enabledSignatures = schoolInfo.signatures.filter(sig => sig.enabled);

  const ReportHeader = () => (
    <header className="text-center border-b-2 border-black pb-2 mb-3">
        <h1 className="text-xl font-bold">{schoolInfo.reportCardTitle}</h1>
        <h2 className="text-lg font-semibold text-gray-700">{schoolInfo.name}</h2>
         <div className="grid grid-cols-4 gap-x-2 gap-y-1 text-sm mt-2">
            <div><strong>دانش‌آموز:</strong> {student.name}</div>
            <div><strong>پایه:</strong> {schoolInfo.gradeLevel}</div>
            <div><strong>کلاس:</strong> {className}</div>
            <div><strong>سال تحصیلی:</strong> {toPersianDigits(schoolInfo.academicYear)}</div>
        </div>
    </header>
  );

  const ReportFooter = () => (
     <footer className="text-center text-xs pt-2 mt-auto border-t-2 border-black text-gray-600">
        تاریخ صدور: {new Date().toLocaleDateString('fa-IR')}
      </footer>
  );

  const FullGradesTable = () => (
    <table className={`w-full text-[10px] border-collapse border`} style={{ borderColor: commonStyles.tableBorderColor }}>
        <thead className='bg-gray-200'>
            <tr>
                <th className="p-1 border" style={{ borderColor: commonStyles.tableBorderColor }}>نام درس</th>
                {Array.from({ length: NUM_GRADES_PER_SUBJECT }).map((_, i) => (
                    <th key={i} className="p-1 border" style={{ borderColor: commonStyles.tableBorderColor }}>{`نمره ${toPersianDigits(i+1)}`}</th>
                ))}
                <th className={`p-1 border font-bold bg-gray-300`} style={{ borderColor: commonStyles.tableBorderColor }}>میانگین درس</th>
            </tr>
        </thead>
        <tbody>
            {student.subjects.map((subject, index) => (
                <tr key={index}>
                    <td className="p-1 border font-semibold" style={{ borderColor: commonStyles.tableBorderColor }}>{subject.name}</td>
                    {subject.grades.map((grade, gIndex) => (
                        <td key={gIndex} className="p-1 border text-center" style={{ borderColor: commonStyles.tableBorderColor }}>{toPersianDigits(grade?.toFixed(2))}</td>
                    ))}
                    <td className={`p-1 border text-center font-bold bg-gray-100`} style={{ borderColor: commonStyles.tableBorderColor }}>{toPersianDigits(subject.average?.toFixed(2))}</td>
                </tr>
            ))}
        </tbody>
    </table>
  );

  const OverallAverageChart = () => {
      const chartData = student.subjects.map(s => ({ name: s.name, میانگین: s.average }));
      return (
        <div className="border border-black p-2">
            <h3 className="text-md font-bold text-center mb-1">نمودار کلی میانگین دروس</h3>
            <ResponsiveContainer width="100%" height={200}>
                <BarChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 40 }} animationDuration={0}>
                    <CartesianGrid strokeDasharray="3 3" stroke={commonStyles.gridStrokeColor} />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={45} interval={0} tick={{ fontSize: 8, fill: commonStyles.tickFillColor }}/>
                    <YAxis type="number" domain={[0, 20]} tick={{ fontSize: 9, fill: commonStyles.tickFillColor }} tickFormatter={toPersianDigits}/>
                    <Tooltip contentStyle={tooltipStyle} formatter={(value: number) => toPersianDigits(value.toFixed(2))} />
                    <Bar dataKey="میانگین" fill={commonStyles.barFillColor} barSize={10} />
                </BarChart>
            </ResponsiveContainer>
        </div>
      );
  };
  
  const IndividualSubjectCharts = () => {
    const gridColsClass = orientation === 'landscape' ? 'grid-cols-5' : 'grid-cols-4';
    return (
         <div 
            className={`flex-grow grid ${gridColsClass} gap-2`}
            style={{ gridAutoRows: `minmax(150px, auto)`}}
          >
            {student.subjects.map(subject => {
                const chartData = subject.grades.map((grade, index) => ({
                    name: `نمره ${toPersianDigits(index + 1)}`,
                    نمره: grade,
                }));

                return (
                    <div key={subject.name} className="border border-gray-400 p-1 flex flex-col">
                        <h3 className="text-center font-bold text-[9px] mb-1">{subject.name}</h3>
                        <div className="flex-grow">
                             <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }} animationDuration={0}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#ccc" />
                                    <XAxis dataKey="name" tick={{ fontSize: 8 }} angle={-45} textAnchor="end" height={25} interval={0} />
                                    <YAxis type="number" domain={[0, 20]} tick={{ fontSize: 8 }} tickFormatter={toPersianDigits}/>
                                    <Tooltip contentStyle={{ fontSize: '9px', padding: '2px 5px' }} formatter={(value: number) => toPersianDigits(value?.toFixed(2))} />
                                    <Bar dataKey="نمره" fill="#4A4A4A" barSize={10} />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                )
            })}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Page 1 */}
      <div id="comprehensive-page-1" className={`${dimensionClasses} p-4 shadow-2xl flex flex-col mx-auto bg-white text-black border-2 border-black text-[10px]`}>
        <ReportHeader />
        <div className="flex-grow overflow-auto py-2">
            <FullGradesTable />
        </div>
        <SignatureSection signatures={enabledSignatures} />
        <ReportFooter />
      </div>

      {/* Page 2 */}
       <div id="comprehensive-page-2" className={`${dimensionClasses} p-4 shadow-2xl flex flex-col mx-auto bg-white text-black border-2 border-black text-[10px]`}>
        <ReportHeader />
        <div className="flex-grow flex flex-col gap-y-2 py-2">
            <OverallAverageChart />
            <IndividualSubjectCharts />
        </div>
        <SignatureSection signatures={enabledSignatures} />
        <ReportFooter />
      </div>
    </div>
  );
};

export default ComprehensiveReport;