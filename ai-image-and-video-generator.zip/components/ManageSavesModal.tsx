import React, { useState, useRef } from 'react';
import { Save, Download, Trash2, X, FileUp, FileDown } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  savedStates: string[];
  onSave: (name: string) => void;
  onLoad: (name: string) => void;
  onDelete: (name: string) => void;
  onExport: () => void;
  onImport: (fileContent: string) => void;
}

const ManageSavesModal: React.FC<Props> = ({ isOpen, onClose, savedStates, onSave, onLoad, onDelete, onExport, onImport }) => {
  const [saveName, setSaveName] = useState('');
  const importFileRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleSaveClick = () => {
    if (!saveName.trim()) {
        alert('لطفاً یک نام برای ذخیره‌سازی وارد کنید.');
        return;
    }
    onSave(saveName);
    setSaveName('');
  };

  const handleImportClick = () => {
    importFileRef.current?.click();
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        onImport(content);
      } else {
        alert('فایل خالی است یا قابل خواندن نیست.');
      }
    };
    reader.onerror = () => {
      alert('خطا در خواندن فایل.');
    };
    reader.readAsText(file, 'UTF-8');

    if (e.target) {
      e.target.value = '';
    }
  };


  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 transition-opacity" onClick={onClose}>
      <div className="bg-white text-gray-800 border border-gray-300 rounded-lg shadow-2xl p-6 w-full max-w-2xl transform transition-all" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center border-b border-gray-200 pb-3 mb-4">
          <h2 className="text-xl font-bold text-gray-900">مدیریت ذخیره‌ها</h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 hover:text-gray-900">
            <X size={24} />
          </button>
        </div>

        <div className="mb-6 bg-gray-50 p-4 rounded-md border border-gray-200">
          <h3 className="font-semibold text-gray-600 mb-2">ذخیره وضعیت فعلی (در همین مرورگر)</h3>
          <div className="flex items-center gap-x-2">
            <input
              type="text"
              value={saveName}
              onChange={(e) => setSaveName(e.target.value)}
              placeholder="مثلاً: پایان ترم اول ۱۴۰۳"
              className="flex-grow p-2 border border-gray-300 bg-white text-gray-800 rounded-md focus:ring-2 focus:ring-blue-500"
            />
            <button onClick={handleSaveClick} className="flex items-center gap-x-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
              <Save size={18} />
              ذخیره
            </button>
          </div>
        </div>

        <div className="mb-6 bg-gray-50 p-4 rounded-md border border-gray-200">
          <h3 className="font-semibold text-gray-600 mb-2">انتقال داده‌ها</h3>
           <p className="text-xs text-gray-500 mb-3">
            می‌توانید از تمام داده‌های برنامه خروجی گرفته و در سیستم دیگری بارگذاری کنید.
          </p>
          <div className="flex items-center gap-x-3">
            <button onClick={onExport} className="flex-1 flex items-center justify-center gap-x-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors">
              <FileDown size={18} />
              خروجی گرفتن از داده‌ها
            </button>
            <button onClick={handleImportClick} className="flex-1 flex items-center justify-center gap-x-2 bg-teal-600 text-white px-4 py-2 rounded-md hover:bg-teal-700 transition-colors">
              <FileUp size={18} />
              بارگذاری داده از فایل
            </button>
            <input
              type="file"
              ref={importFileRef}
              onChange={handleFileSelected}
              accept=".json,application/json"
              className="hidden"
            />
          </div>
        </div>
        
        <div>
          <h3 className="font-semibold text-gray-600 mb-2">بارگذاری یا حذف وضعیت‌های ذخیره شده (محلی)</h3>
          <div className="max-h-60 overflow-y-auto border border-gray-200 rounded-md">
            {savedStates.length > 0 ? (
              <ul className="divide-y divide-gray-200">
                {savedStates.map(name => (
                  <li key={name} className="p-3 flex justify-between items-center hover:bg-gray-100">
                    <span className="font-medium text-gray-800">{name}</span>
                    <div className="flex items-center gap-x-2">
                      <button onClick={() => onLoad(name)} className="flex items-center gap-x-2 text-sm bg-green-600 text-white px-3 py-1 rounded-md hover:bg-green-700 transition-colors">
                        <Download size={16} />
                        بارگذاری
                      </button>
                      <button onClick={() => onDelete(name)} className="p-2 text-red-500 hover:bg-red-500/10 rounded-full transition-colors">
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-center text-gray-500 p-6">هیچ وضعیت ذخیره شده‌ای وجود ندارد.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageSavesModal;
