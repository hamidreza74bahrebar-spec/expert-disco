import React from 'react';
import { EnrichedStudentData } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import PrintControls from './PrintControls';
import { toPersianDigits } from '../services/calculationService';

interface Props {
  students: EnrichedStudentData[];
}

const RankingView: React.FC<Props> = ({ students }) => {
  const sortedStudents = [...students].sort((a, b) => (a.rank ?? Infinity) - (b.rank ?? Infinity));
  
  const chartData = sortedStudents
    .filter(s => s.totalAverage !== null)
    .map(s => ({ name: s.name, 'معدل کل': s.totalAverage }));

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
      <div className="flex justify-between items-center mb-4 pb-2 border-b border-gray-300">
        <h2 className="text-2xl font-bold text-gray-800">رتبه‌بندی و مقایسه معدل</h2>
        <PrintControls printAreaId="ranking-print-area" />
      </div>
      <div id="ranking-print-area">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <h3 className="text-xl font-bold mb-4 text-gray-700 text-center">جدول رتبه‌بندی</h3>
            <div className="overflow-y-auto max-h-[500px] border border-gray-300 rounded-md">
                <table className="w-full text-sm text-center">
                <thead className="bg-gray-100 sticky top-0">
                    <tr>
                    <th className="p-3 font-semibold">رتبه</th>
                    <th className="p-3 font-semibold text-right">نام دانش‌آموز</th>
                    <th className="p-3 font-semibold">معدل کل</th>
                    </tr>
                </thead>
                <tbody>
                    {sortedStudents.map(student => (
                    <tr key={student.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="p-3 font-bold text-lg text-blue-600">{toPersianDigits(student.rank)}</td>
                        <td className="p-3 text-right">{student.name}</td>
                        <td className="p-3 font-semibold">{toPersianDigits(student.totalAverage?.toFixed(2))}</td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>
          </div>
          <div className="lg:col-span-2">
            <h3 className="text-xl font-bold mb-4 text-gray-700 text-center">نمودار مقایسه معدل</h3>
            <ResponsiveContainer width="100%" height={500}>
              <BarChart
                data={chartData}
                margin={{
                  top: 5, right: 30, left: 20, bottom: 80,
                }}
              >
                <defs>
                  <linearGradient id="rankingGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.2}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" interval={0} tick={{ fontSize: 12, fill: '#4b5563' }} />
                <YAxis domain={[0, 20]} tickFormatter={toPersianDigits} tick={{ fill: '#4b5563' }} />
                <Tooltip
                  cursor={{ fill: 'rgba(59, 130, 246, 0.2)' }}
                  formatter={(value: number) => toPersianDigits(value.toFixed(2))}
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    color: '#1f2937',
                  }}
                />
                <Legend wrapperStyle={{ color: '#374151' }}/>
                <Bar dataKey="معدل کل" fill="url(#rankingGradient)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RankingView;