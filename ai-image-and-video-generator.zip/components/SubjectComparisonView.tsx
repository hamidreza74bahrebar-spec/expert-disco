import React from 'react';
import { SubjectClassMetrics } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, ClipboardList, Trash2 } from 'lucide-react';
import PrintControls from './PrintControls';
import { toPersianDigits } from '../services/calculationService';

interface Props {
  subjectMetrics: SubjectClassMetrics[];
  onDeleteSubject: (subjectName: string) => void;
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        const data = payload[0].payload;
        return (
        <div className="p-2 bg-white border border-gray-300 rounded shadow-lg text-sm text-gray-700" dir="rtl">
            <p className="font-bold border-b border-gray-200 mb-1 pb-1">{label}</p>
            <p className="font-semibold" style={{ color: payload[0].fill }}>{`میانگین: ${toPersianDigits(data.average.toFixed(2))}`}</p>
            <p className="text-red-600">{`کمترین نمره: ${toPersianDigits(data.min.toFixed(2))}`}</p>
            <p className="text-green-600">{`بیشترین نمره: ${toPersianDigits(data.max.toFixed(2))}`}</p>
        </div>
        );
    }
    return null;
};


const SubjectComparisonView: React.FC<Props> = ({ subjectMetrics, onDeleteSubject }) => {
  const sortedByAverage = [...subjectMetrics].sort((a, b) => b.average - a.average);
  const highest = sortedByAverage[0];
  const lowest = sortedByAverage[sortedByAverage.length - 1];

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
       <div className="flex justify-between items-center mb-4 pb-2 border-b border-gray-300">
        <h2 className="text-2xl font-bold text-gray-800">تحلیل و مقایسه دروس</h2>
        <PrintControls printAreaId="subject-print-area" />
      </div>

      <div id="subject-print-area">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-gray-50 p-6 rounded-lg shadow-inner flex items-center space-i-4 border border-gray-200">
            <TrendingUp className="w-12 h-12 text-green-500" />
            <div>
                <h3 className="text-md text-gray-500">بالاترین میانگین</h3>
                <p className="text-xl font-bold text-gray-800">{highest?.name || '-'}</p>
                <p className="text-2xl font-bold text-green-600">{highest ? toPersianDigits(highest.average.toFixed(2)) : '-'}</p>
            </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg shadow-inner flex items-center space-i-4 border border-gray-200">
            <ClipboardList className="w-12 h-12 text-blue-500" />
            <div>
                <h3 className="text-md text-gray-500">تعداد دروس</h3>
                <p className="text-2xl font-bold text-blue-600">{toPersianDigits(subjectMetrics.length)}</p>
            </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg shadow-inner flex items-center space-i-4 border border-gray-200">
            <TrendingDown className="w-12 h-12 text-red-500" />
            <div>
                <h3 className="text-md text-gray-500">پایین‌ترین میانگین</h3>
                <p className="text-xl font-bold text-gray-800">{lowest?.name || '-'}</p>
                <p className="text-2xl font-bold text-red-600">{lowest ? toPersianDigits(lowest.average.toFixed(2)) : '-'}</p>
            </div>
            </div>
        </div>
        
        <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
            <div className="xl:col-span-3">
                <h3 className="text-xl font-bold mb-4 text-gray-700 text-center">نمودار مقایسه میانگین دروس</h3>
                <ResponsiveContainer width="100%" height={400}>
                <BarChart
                    data={subjectMetrics}
                    margin={{ top: 5, right: 30, left: 20, bottom: 40 }}
                >
                    <defs>
                    <linearGradient id="subjectGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#818cf8" stopOpacity={0.9}/>
                        <stop offset="95%" stopColor="#818cf8" stopOpacity={0.3}/>
                    </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" interval={0} tick={{ fontSize: 10, fill: '#4b5563' }} height={60} />
                    <YAxis domain={[0, 20]} tickFormatter={toPersianDigits} tick={{ fill: '#4b5563' }} />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(129, 140, 248, 0.2)' }} />
                    <Legend wrapperStyle={{ color: '#374151' }} />
                    <Bar dataKey="average" name="میانگین کلاس" fill="url(#subjectGradient)" radius={[4, 4, 0, 0]} />
                </BarChart>
                </ResponsiveContainer>
            </div>

            <div className="xl:col-span-2">
            <h3 className="text-xl font-bold mb-4 text-gray-700 text-center">لیست کامل دروس</h3>
                <div className="overflow-y-auto max-h-[400px] border border-gray-200 rounded-md">
                    {subjectMetrics.length > 0 ? (
                        <table className="w-full text-sm">
                            <thead className="bg-gray-100 sticky top-0">
                                <tr>
                                    <th className="p-3 font-semibold text-right">نام درس</th>
                                    <th className="p-3 font-semibold text-center">میانگین</th>
                                    <th className="p-3 font-semibold text-center">کمترین نمره</th>
                                    <th className="p-3 font-semibold text-center">بیشترین نمره</th>
                                    <th className="p-3 font-semibold text-center">عملیات</th>
                                </tr>
                            </thead>
                            <tbody>
                                {sortedByAverage.map(subject => (
                                <tr key={subject.name} className="border-b border-gray-200 hover:bg-gray-50">
                                    <td className="p-3 text-right">{subject.name}</td>
                                    <td className="p-3 font-semibold text-center">{toPersianDigits(subject.average.toFixed(2))}</td>
                                    <td className="p-3 font-semibold text-center text-red-500">{toPersianDigits(subject.min.toFixed(2))}</td>
                                    <td className="p-3 font-semibold text-center text-green-500">{toPersianDigits(subject.max.toFixed(2))}</td>
                                    <td className="p-3 text-center">
                                    <button
                                        onClick={() => onDeleteSubject(subject.name)}
                                        className="text-red-500 hover:text-red-700 p-1 hover:bg-red-500/10 rounded-full transition-colors"
                                        title={`حذف درس ${subject.name}`}
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                    </td>
                                </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <p className="text-center text-gray-500 p-6">درسی برای نمایش وجود ندارد.</p>
                    )}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default SubjectComparisonView;