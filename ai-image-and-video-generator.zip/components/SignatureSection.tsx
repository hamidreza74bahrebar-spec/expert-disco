import React from 'react';
import { Signature } from '../types';

interface Props {
  signatures: Signature[];
}

const SignatureSection: React.FC<Props> = ({ signatures }) => {
  if (!signatures || signatures.length === 0) {
    return null;
  }

  return (
    <div className="w-full pt-4 flex justify-around items-end gap-x-4 mt-auto">
      {signatures.map((sig, index) => (
        <div key={index} className="flex-1 text-center p-2">
          <div className="h-12 mb-2 border-b border-dashed border-gray-600 print:border-black">
            {/* This space is for the signature */}
          </div>
          <p className="text-xs font-bold">{sig.name}</p>
          <p className="text-[9px] text-gray-600 print:text-gray-700">{sig.title}</p>
        </div>
      ))}
    </div>
  );
};

export default SignatureSection;