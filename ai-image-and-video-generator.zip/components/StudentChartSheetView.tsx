import React, { useState } from 'react';
import { SchoolInfo, EnrichedStudentData, AppSettings } from '../types';
import ComprehensiveReport from './StudentChartSheet';
import { Printer, FileSymlink, ChevronsRightLeft, BarChart2, Download, Users, FileText } from 'lucide-react';
import { toPersianDigits } from '../services/calculationService';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

type PaperSize = 'a4' | 'a5';
type Orientation = 'portrait' | 'landscape';

interface Props {
  students: EnrichedStudentData[];
  schoolInfo: SchoolInfo;
  className: string;
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
}

const ComprehensiveReportView: React.FC<Props> = ({ students, schoolInfo, className, settings, setSettings }) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(students.length > 0 ? students[0].id : null);
  const [paperSize, setPaperSize] = useState<PaperSize>('a4');
  const [orientation, setOrientation] = useState<Orientation>('portrait');
  const [isGeneratingFile, setIsGeneratingFile] = useState(false);
  const [generationMessage, setGenerationMessage] = useState('');
  const [bulkRenderStudent, setBulkRenderStudent] = useState<EnrichedStudentData | null>(null);

  const selectedStudent = students.find(s => s.id === selectedStudentId);

  const handlePrint = () => {
    let style = document.getElementById('print-settings-style');
    if (!style) {
        style = document.createElement('style');
        style.id = 'print-settings-style';
        document.head.appendChild(style);
    }
    style.innerHTML = `@media print { @page { size: ${paperSize} ${orientation}; margin: 0.5cm; } }`;
    
    const printArea = document.getElementById('chart-sheet-print-area');
    if (printArea) {
      const originalId = printArea.id;
      printArea.id = 'print-area';
      window.print();
      printArea.id = originalId;
    }
  };

  const generatePdfForStudent = async (pdf: jsPDF, student: EnrichedStudentData) => {
    setBulkRenderStudent(student);
    await new Promise(resolve => setTimeout(resolve, 100));

    const page1Element = document.getElementById('comprehensive-page-1');
    const page2Element = document.getElementById('comprehensive-page-2');

    if (page1Element && page2Element) {
        const canvas1 = await html2canvas(page1Element, { scale: 2, useCORS: true, logging: false });
        const canvas2 = await html2canvas(page2Element, { scale: 2, useCORS: true, logging: false });

        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();

        pdf.addImage(canvas1.toDataURL('image/png'), 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.addPage();
        pdf.addImage(canvas2.toDataURL('image/png'), 'PNG', 0, 0, pdfWidth, pdfHeight);
    }
  };

  const handleDownloadPdf = async () => {
    if (!selectedStudent) return;
    setIsGeneratingFile(true);
    setGenerationMessage('در حال آماده‌سازی PDF...');

    try {
        const pdf = new jsPDF({ orientation, unit: 'mm', format: paperSize });
        await generatePdfForStudent(pdf, selectedStudent);
        pdf.save(`کارنامه-جامع-${selectedStudent.name}.pdf`);
    } catch (error) {
        console.error("Error creating PDF:", error);
        alert("خطا در ایجاد فایل PDF.");
    } finally {
        setIsGeneratingFile(false);
        setGenerationMessage('');
        setBulkRenderStudent(null);
    }
  };

  const handleBulkDownloadPdf = async () => {
    if (students.length === 0) return;
    setIsGeneratingFile(true);

    try {
        const pdf = new jsPDF({ orientation, unit: 'mm', format: paperSize });
        for (let i = 0; i < students.length; i++) {
            setGenerationMessage(`آماده‌سازی PDF: ${toPersianDigits(i + 1)} از ${toPersianDigits(students.length)}`);
            if (i > 0) pdf.addPage();
            await generatePdfForStudent(pdf, students[i]);
        }
        pdf.save(`کارنامه-جامع-کلاس-${className}.pdf`);
    } catch (error) {
        console.error("Error creating bulk PDF:", error);
        alert("خطا در ایجاد فایل PDF گروهی.");
    } finally {
        setIsGeneratingFile(false);
        setGenerationMessage('');
        setBulkRenderStudent(null);
    }
  };

   const handleBulkDownloadWord = async () => {
      if (students.length === 0) return;
      setIsGeneratingFile(true);
      let allReportCardsHtml = '';
      
      try {
          for (let i = 0; i < students.length; i++) {
              const student = students[i];
              setGenerationMessage(`آماده‌سازی Word: ${toPersianDigits(i + 1)} از ${toPersianDigits(students.length)}`);
              setBulkRenderStudent(student);
              await new Promise(resolve => setTimeout(resolve, 100));

              const page1Element = document.getElementById('comprehensive-page-1');
              const page2Element = document.getElementById('comprehensive-page-2');

              if (page1Element && page2Element) {
                  allReportCardsHtml += page1Element.innerHTML;
                  allReportCardsHtml += '<div style="page-break-after: always;"></div>';
                  allReportCardsHtml += page2Element.innerHTML;
                  if (i < students.length - 1) {
                      allReportCardsHtml += '<div style="page-break-after: always;"></div>';
                  }
              }
          }

          const header = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>کارنامه‌های جامع کلاس ${className}</title><style>body { font-family: ${settings.fontFamilyBody}; font-size: ${settings.baseFontSize}px; direction: rtl; } h1, h2, h3, h4, h5, h6, .font-heading { font-family: ${settings.fontFamilyHeading}; } @page { size: ${paperSize} ${orientation}; margin: 1cm; }</style></head><body>`;
          const source = header + allReportCardsHtml + '</body></html>';
          
          const blob = new Blob(['\uFEFF', source], { type: 'application/vnd.ms-word' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = url;
          link.download = `کارنامه-جامع-کلاس-${className}.doc`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);

      } catch(error) {
          console.error("Error creating bulk Word file:", error);
          alert("خطا در ایجاد فایل Word گروهی.");
      } finally {
          setIsGeneratingFile(false);
          setGenerationMessage('');
          setBulkRenderStudent(null);
      }
  };

  if (students.length === 0) {
    return <div className="text-center p-6 bg-white rounded-lg shadow border">دانش‌آموزی برای نمایش برگه تحلیلی وجود ندارد.</div>
  }

  return (
    <div>
      <div className="mb-6 p-4 bg-white rounded-lg shadow-md border flex flex-wrap items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-x-4 flex-wrap">
          <div className="flex items-center gap-x-4">
              <label htmlFor="student-select" className="font-semibold text-lg text-gray-700">دانش‌آموز:</label>
              <select
                id="student-select"
                value={selectedStudentId ?? ''}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="p-2 border border-gray-300 bg-white text-gray-800 rounded-md focus:ring-2 focus:ring-blue-500"
              >
                {students.map(student => (
                  <option key={student.id} value={student.id}>{student.name}</option>
                ))}
              </select>
          </div>
        </div>
        <div className="flex items-center gap-x-3 flex-wrap">
            <div className="flex items-center gap-x-2">
                <FileSymlink size={18} className="text-gray-500" />
                <select value={paperSize} onChange={e => setPaperSize(e.target.value as PaperSize)} className="p-2 border border-gray-300 bg-white rounded-md">
                    <option value="a4">A4</option>
                    <option value="a5">A5</option>
                </select>
            </div>
             <div className="flex items-center gap-x-2">
                <ChevronsRightLeft size={18} className="text-gray-500" />
                <select value={orientation} onChange={e => setOrientation(e.target.value as Orientation)} className="p-2 border border-gray-300 bg-white rounded-md">
                    <option value="portrait">عمودی</option>
                    <option value="landscape">افقی</option>
                </select>
            </div>
            <div className="border-l h-6 border-gray-300 mx-1"></div>
            <button
                onClick={handleBulkDownloadPdf}
                disabled={isGeneratingFile}
                className="flex items-center gap-x-2 bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-400"
            >
                <Users size={18} />
                {isGeneratingFile ? generationMessage : 'PDF گروهی'}
            </button>
             <button
                onClick={handleBulkDownloadWord}
                disabled={isGeneratingFile}
                className="flex items-center gap-x-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors disabled:bg-gray-400"
            >
                <FileText size={18} />
                {isGeneratingFile ? generationMessage : 'Word گروهی'}
            </button>
            <div className="border-l h-6 border-gray-300 mx-1"></div>
             <button
                onClick={handleDownloadPdf}
                disabled={!selectedStudent || isGeneratingFile}
                className="flex items-center gap-x-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors disabled:bg-gray-400"
            >
                <Download size={18} />
                {isGeneratingFile ? generationMessage : 'دانلود PDF'}
            </button>
            <button
                onClick={handlePrint}
                 disabled={isGeneratingFile}
                className="flex items-center gap-x-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
            >
                <Printer size={18} />
                چاپ
            </button>
        </div>
      </div>
      
       {/* Hidden container for bulk rendering */}
       {bulkRenderStudent && (
          <div id="bulk-render-container" className="absolute -left-[9999px] top-0 z-[-1] direction-rtl">
              <ComprehensiveReport 
                    student={bulkRenderStudent} 
                    schoolInfo={schoolInfo} 
                    className={className} 
                    paperSize={paperSize} 
                    orientation={orientation} 
                    settings={settings}
                />
          </div>
       )}

      {selectedStudent ? (
        <div id="chart-sheet-print-area" className="mx-auto bg-gray-200 p-4">
            <ComprehensiveReport 
                student={selectedStudent} 
                schoolInfo={schoolInfo} 
                className={className} 
                paperSize={paperSize} 
                orientation={orientation} 
                settings={settings}
            />
        </div>
      ) : (
        <div className="text-center p-6 bg-white rounded-lg shadow border">لطفا یک دانش‌آموز را انتخاب کنید.</div>
      )}
    </div>
  );
};

export default ComprehensiveReportView;