import React, { useMemo } from 'react';
import { Student } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  subjectName: string;
  students: Student[];
}

const SubjectDistributionChartModal: React.FC<Props> = ({ isOpen, onClose, subjectName, students }) => {
  const chartData = useMemo(() => {
    if (!isOpen) return [];

    const bins = [
      { name: 'عالی (17-20)', range: [17, 20.01], count: 0, color: '#16a34a' },
      { name: 'خیلی خوب (14-17)', range: [14, 17], count: 0, color: '#2563eb' },
      { name: 'خوب (10-14)', range: [10, 14], count: 0, color: '#f97316' },
      { name: 'نیاز به تلاش (زیر 10)', range: [0, 10], count: 0, color: '#dc2626' },
    ];

    students.forEach(student => {
      const subject = student.subjects.find(s => s.name === subjectName);
      if (subject) {
        const validGrades = subject.grades.filter(g => g !== null) as number[];
        validGrades.forEach(grade => {
          for (const bin of bins) {
            if (grade >= bin.range[0] && grade < bin.range[1]) {
              bin.count++;
              break;
            }
          }
        });
      }
    });

    return bins;
  }, [isOpen, subjectName, students]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50" onClick={onClose}>
      <div className="bg-white text-gray-800 border border-gray-300 rounded-lg shadow-2xl p-6 w-full max-w-2xl transform" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center border-b border-gray-200 pb-3 mb-4">
          <h2 className="text-xl font-bold text-gray-900">تحلیل نمرات درس: {subjectName}</h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 hover:text-gray-800">
            <X size={24} />
          </button>
        </div>
        <p className="text-sm text-gray-600 mb-4">
            این نمودار توزیع تمام نمرات ثبت شده برای این درس را در بین تمام دانش‌آموزان کلاس نشان می‌دهد.
        </p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis type="number" allowDecimals={false} tick={{ fill: '#4b5563' }}/>
            <YAxis type="category" dataKey="name" width={120} tick={{ fill: '#4b5563' }}/>
            <Tooltip
                cursor={{ fill: 'rgba(59, 130, 246, 0.2)' }}
                contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    color: '#1f2937'
                }}
            />
            <Bar dataKey="count" name="تعداد نمرات">
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default SubjectDistributionChartModal;